//Austin Youngren

#pragma once

#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include "Person.h"
#include "Clan.h"