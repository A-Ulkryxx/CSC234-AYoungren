//Austin Youngren
#include "Header.h"
using namespace std;

//use this method to see if you code is working.  Remove once you have the overloaded operator << working
void Person:: printPerson()
{
	cout << "Name: " << personName;
	cout << "  Age: " << age << endl;
}